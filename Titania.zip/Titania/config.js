function Config() {}
var config = new Config();
config.size = 8;
config.step = 256;
config.x = 1057;
config.y = 992;
config.mode = "3d";
config.showDeedBordersIn3dMode = false;
config.showDeedBordersInFlatMode = true;

function Deed(name, x, y, height, permanent, sx, sy, ex, ey) {
	this.name = name;
	this.x = x;
	this.y = y;
	this.sx = sx;
	this.sy = sy;
	this.ex = ex;
	this.ey = ey;
	this.height = height;
	this.permanent = permanent;
}

var deeds = [];
deeds.push(new Deed('Sunset Retreat', 1226, 552, 140, false, 1214, 529, 1244, 575));
deeds.push(new Deed('Lonely Island', 178, 1692, 288, false, 138, 1652, 218, 1732));
deeds.push(new Deed('Southbank', 973, 1086, 1, false, 953, 1061, 998, 1111));
deeds.push(new Deed('Misty Harbour', 1051, 887, 7, false, 1026, 862, 1076, 912));
deeds.push(new Deed('Jackaranch', 1191, 876, 9, false, 1186, 871, 1196, 881));
deeds.push(new Deed('Yorkshire', 1030, 1111, 92, false, 1025, 1106, 1035, 1116));
deeds.push(new Deed('Camelot', 1057, 992, 81, true, 1004, 957, 1090, 1047));
deeds.push(new Deed('Lakeview', 994, 938, 37, false, 989, 923, 999, 943));
